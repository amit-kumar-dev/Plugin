jQuery(document).ready(function() {
	jQuery("#complete_order_mark_Modal").modal();//if you want you can have a timeout to hide the window after x seconds
});