<?php

namespace Box\Spout\Common\Exception;

/**
 * Class InvalidArgumentException
 *
 * @api
 * @package Box\Spout\Common\Exception
 */
class InvalidArgumentException extends SpoutException
{
}
